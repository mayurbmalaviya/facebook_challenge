<?php
/* 
A domain Class to demonstrate RESTful web services
*/
Class Faculty {
	
	private $faculty = array(
		0 => 'Not Found',
		1 => 'Prof. Smita Agrawal',  
		2 => 'Prof. Sonia Mittal',  
		3 => 'Prof. Anitha Ashokan',  			
		4 => 'Prof. Preeti Kathiria',  			
		5 => 'Prof. Deepika Shukla',  
		6 => 'Prof. Lata Gohil'
		);
		
	/*
		you should add method/behaviour of Faculty Model
	*/
	public function getAllFaculties(){
		return $this->faculty;
	}
	
	public function getFaculty($id){
		
		$faculty = array($id => ($this->faculty[$id]) ? $this->faculty[$id] : $this->faculty[0]);
		return $faculty;
	}	
}
?>